/*
 * @Author: your name
 * @Date: 2020-04-07 15:49:06
 * @LastEditTime: 2020-04-12 14:02:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /maven-hello-world/src/main/java/numberRecognizer/ImageHandler.java
 */
package numberRecognizer;

import java.io.*;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;

import javax.imageio.ImageIO;

public class ImageHandler {
    private static final String folderPath = "src/numberRecognizer/11.png";
    private static float[][] rgbArr;

    /**
     * @description: read a image file as stream from the specific path and transform it to 
     *              BufferedImage
     * @param none
     * @return: BufferedImage
     */
    private static BufferedImage getImage() {
            try {
                InputStream input = new FileInputStream(new File(folderPath));
                BufferedImage img = ImageIO.read(input);
                return img;
            } catch (FileNotFoundException e1) {
                // TODO: handle exception
            } catch (IOException e2) {
                // TODO: handle exception
            }
        return null;
    }

    /**
     * @description: transform a BufferedImage to 2-dimentional float array
     * @param none
     * @return: float[][]
     */   
    public static float[][] convertImageToArray() {
    	BufferedImage image = getImage();
    	Raster ra = image.getData();
    	  // get the image's width and height
    	  int width = image.getWidth();
    	  int height = image.getHeight();
    	//get the image's pixels for each point
    	  int[] pixels = new int[width * height];
  		pixels = ra.getPixels(0, 0, width, height, pixels); 

  		//convert the int array to a float array and make each pixel's value is between 0 and 1
  		//while 0 is pure whit and 1 is pure black
  		float[] temp = new float[width * height];
  		for(int i = 0; i < pixels.length; i++) {
       	    temp[i] = (255-pixels[i])*1.0f/255.0f;
       	    }
    	   
    	   //convert float array to 2-dimentional float arry
    	   rgbArr = new float[1][width*height];
    	   for(int i = 0; i < width*height; i++) {
       	    rgbArr[0][i] = temp[i];
       	    }
    	   return rgbArr;
    	   }
}