package numberRecognizer;

import org.tensorflow.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

 public class ModelRecognize {
	 private static float[][] target;
	 private static int result;
     public static int getResult() throws Exception {
    	 //load the model which has been trained before
 		byte[] graphDef = readAllBytesOrExit(Paths.get(
 				"src/grf.pb"));
 		Graph g = new Graph();
 		g.importGraphDef(graphDef);
 		//create a session to pass input and get output of the model
 		Session sess = new Session(g);
 		//target is the target image which has been preprocessed and convert to a 2-dimentinal float array
		target = ImageHandler.convertImageToArray();
		//create input
        Tensor input_x = Tensor.create(target);
        //pass the input and get the result out of the model
        List<Tensor<?>> out = sess.runner().feed("input_x", input_x).fetch("final_result").run();
        //the result out is a list of possibilities for each number from 0 to 9.
        //and we need to find out which one has the highest possibility.
         for (Tensor s : out) {
             float[][] t = new float[1][10];
             s.copyTo(t);
             float max = 0f;//float i : t[0]
             for (int i = 0; i<t[0].length; i++) {
            	 if(max<t[0][i]) {
            		 max = t[0][i];
            		 result = i;
            	  }     
             }
         }
         return result;
     }
     
     /**
      * @description: read a file as a byte array according to its path and handle the exception
      *              
      * @param path of the file
      * @return: byte[]
      */
     private static byte[] readAllBytesOrExit(Path path) {
 		try {
 		return Files.readAllBytes(path);
 		} catch (IOException e) {
 		System.err.println("Failed to read [" + path + "]: "
 		+ e.getMessage());
 		System.exit(1);
 		}
 		return null;
 		}
 }