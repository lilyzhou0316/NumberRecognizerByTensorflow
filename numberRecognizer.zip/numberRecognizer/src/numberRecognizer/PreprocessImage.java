/*
 * @Author: Xiaoli Zhou
 * @Date: 2020-04-12 20:05:29
 * @LastEditTime: 2020-04-12 20:48:45
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: src/numberRecognize/PreprocessImage.java
 */
package numberRecognizer;

import java.io.File;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;


public class PreprocessImage {
	//load opencv library
	static {
		String opencvpath = "/Users/zhouxiaoli/Desktop/eclipse/numberRecognizer/src/libopencv_java3410.dylib";
		System.load(opencvpath);
	}
	
	public static void preprocess() {
		
	      //read image from its folder
			Mat originalImg = Imgcodecs.imread("src/numberRecognizer/" + "1.png");
	       //resize the original image to 28*28 pixels
	        Imgproc.resize(originalImg, originalImg, new Size(28,28));
		
			//change resized image to gray image
		  Imgproc.cvtColor(originalImg, originalImg, Imgproc.COLOR_BGR2GRAY);
		  
	      // save the image which has been processed
	      Imgcodecs.imwrite("src/numberRecognizer/" + "11.png", originalImg);
	    
		  
	}
}